---
Title: Home
---
[image photo.jpg Example rounded]

[edit - You can edit this page in a web browser] or use a text editor. [Get help](https://datenstrom.se/yellow/help/).
